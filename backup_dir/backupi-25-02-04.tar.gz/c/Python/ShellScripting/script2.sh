# Create a new folder 
pwd
mkdir source src bin
cd source 
pwd

