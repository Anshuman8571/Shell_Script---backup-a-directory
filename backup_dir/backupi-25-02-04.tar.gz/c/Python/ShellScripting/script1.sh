echo "Welcome to the program"

threshold=800

echo "Value of the threshold is $threshold"

current_directory=$(pwd)

echo "The current directory is $current_directory"

