ls

ls -a

pwd
echo "Hello Baby!!!"
